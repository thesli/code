function u = img2var(filename)
    u = double(imread(filename));
return;