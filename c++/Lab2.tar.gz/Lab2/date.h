class Date {
public:
  Date(int day, int month, int year);
  Date();
  void set(int,int,int);
  void print();

private:
  int day;
  int month;
  int year;
};