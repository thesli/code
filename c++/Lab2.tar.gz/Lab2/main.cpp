#include <iostream>
#include "date.h"
#include <ctime>
using namespace std;

int main() {
  int day, month, year;
  cout << "Enter today's date (day month year): ";
  cin >> day >> month >> year;
  Date today(day, month, year);  
  cout << "Today is ";
  today.print();
  //TO DO: display the date of today

  Date deadline;
  deadline.set(23,2,2014);  
  //TO DO: set the date of assignment's deadline
  cout << "The deadline of this assessment is ";
  deadline.print();
  //TO DO: display the date of assignment's deadline

  return 0;
};